<?php
class ODBCConnection extends Connection
{
	protected $ODBCString;
	protected $odbcParams = array();


	function __construct( $params )
	{
		parent::__construct( $params );
	}

	/**
	 * Set db connection's properties
	 * @param Array params
	 */
	protected function assignConnectionParams( $params )
	{
		parent::assignConnectionParams( $params );

		$this->ODBCString = $params["ODBCString"];
		
		$connParts = explode( ';', $this->ODBCString );
		foreach( $connParts as $part ) {
			$eqPos = strpos( $part, '=' );
			if( $eqPos === false ) {
				continue;
			}
			$name = strtolower( substr( $part, 0, $eqPos ) );
			$value = substr( $part, $eqPos + 1 );
			$this->odbcParams[ $name ] = $value;
		}
		
	}

	/**
	 * Open a connection to db
	 */
	public function connect()
	{
		$uid = "";
		$pwd = "";
		if( $this->dbType == nDATABASE_Informix || $this->dbType == nDATABASE_Interbase || $this->dbType == nDATABASE_DB2 || $this->dbType == nDATABASE_iSeries )
		{
			$uid = $this->odbcParams['uid'];
			$pwd = $this->odbcParams['pwd'];
		}

		$this->conn = odbc_connect( $this->ODBCString, $uid, $pwd );
		if( !$this->conn )
			$this->triggerError( $this->lastError() );

		return $this->conn;
	}

	/**
	 * Close the db connection
	 */
	public function close()
	{
		return odbc_close( $this->conn );
	}

	/**
	 * Send an SQL query
	 * @param String sql
	 * @return Mixed
	 */
	public function query( $sql )
	{
		$this->debugInfo($sql);

		$rs = odbc_exec( $this->conn, $sql );
		if( !$rs )
		{
			$this->triggerError( $this->lastError() );
			return FALSE;
		}

		odbc_binmode($rs, ODBC_BINMODE_RETURN);
		odbc_longreadlen($rs, 1024*1024);
		return new QueryResult( $this, $rs );
	}

	/**
	 * Execute an SQL query
	 * @param String sql
	 */
	public function exec( $sql )
	{
		$this->debugInfo($sql);
		return odbc_exec( $this->conn, $sql );
	}

	/**
	 * Get a description of the last error
	 * @return String
	 */
	public function lastError()
	{
		return @odbc_errormsg();
	}

	/**
	 * Fetch a result row as an associative array
	 * @param Mixed qHanle		The query handle
	 * @return Array
	 */
	public function fetch_array( $qHandle )
	{
		return odbc_fetch_array($qHandle);
	}

	/**
	 * Fetch a result row as a numeric array
	 * @param Mixed qHanle		The query handle
	 * @return Array
	 */
	public function fetch_numarray( $qHandle )
	{
		$row = array();
		odbc_fetch_into($qHandle, $row);

		return $row;
	}

	/**
	 * Free resources associated with a query result set
	 * @param Mixed qHanle		The query handle
	 */
	public function closeQuery( $qHandle )
	{
		@odbc_free_result($qHandle);
	}

	/**
	 * Get number of fields in a result
	 * @param Mixed qHanle		The query handle
	 * @return Number
	 */
	public function num_fields( $qHandle )
	{
		return @odbc_num_fields($qHandle);
	}

	/**
	 * Get the name of the specified field in a result
	 * @param Mixed qHanle		The query handle
	 * @param Number offset
	 * @return String
	 */
	public function field_name( $qHandle, $offset )
	{
		return @odbc_field_name($qHandle, $offset + 1);
	}

	/**
	 * @param Mixed qHandle
	 */
	public function seekRecord($qHandle, $n)
	{
		$i = 0;

		while( $i < $n )
		{
			odbc_fetch_row( $qHandle );
			$i++;
		}
	}

	/**
	 * Execute an SQL query with blob fields processing
	 * @param String sql
	 * @param Array blobs
	 * @param Array blobTypes
	 * @return Boolean
	 */
	public function execWithBlobProcessing( $sql, $blobs, $blobTypes = array(), $autoincField = null )
	{
		$this->debugInfo($sql);
		set_error_handler("empty_error_handler");
		$qResult = odbc_exec( $this->conn, $sql );
		set_error_handler("runner_error_handler");

		return $qResult;
	}
}
?>
<?php
global $runnerDatabases;
$runnerDatabases = array(
	'conn' => array(
		'connId' => 'conn',
		'connName' => 'dbtaller at localhost',
		'dbType' => 0,
		'connStringType' => 'mysql',
		'connInfo' => array( 
			'localhost',
			'root',
			'',
			'',
			'dbtaller',
			'',
			'1' 
		) 
	) 
);

global $runnerRestConnections;
$runnerRestConnections = array(
	 
);

?>
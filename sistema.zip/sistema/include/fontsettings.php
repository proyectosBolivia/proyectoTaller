<?php
	$fontSettings_var = array( 
	 
);
?>